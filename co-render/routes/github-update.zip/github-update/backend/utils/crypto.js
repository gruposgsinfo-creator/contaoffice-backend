import { createCipheriv, createDecipheriv, randomBytes } from 'crypto';

const ALGO    = 'aes-256-gcm';
const KEY_HEX = process.env.ENCRYPTION_KEY || '';

function getKey() {
  if (!KEY_HEX || KEY_HEX.length !== 64)
    throw new Error('ENCRYPTION_KEY debe ser 64 hex chars.');
  return Buffer.from(KEY_HEX, 'hex');
}

export function encrypt(plaintext) {
  if (!plaintext) return plaintext;
  const key    = getKey();
  const iv     = randomBytes(12);
  const cipher = createCipheriv(ALGO, key, iv);
  const enc    = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()]);
  const tag    = cipher.getAuthTag();
  return `${iv.toString('hex')}:${tag.toString('hex')}:${enc.toString('hex')}`;
}

export function decrypt(ciphertext) {
  if (!ciphertext) return ciphertext;
  if (!ciphertext.includes(':')) return ciphertext;
  try {
    const key  = getKey();
    const [ivHex, tagHex, encHex] = ciphertext.split(':');
    const decipher = createDecipheriv(ALGO, key, Buffer.from(ivHex, 'hex'));
    decipher.setAuthTag(Buffer.from(tagHex, 'hex'));
    return decipher.update(Buffer.from(encHex, 'hex'), undefined, 'utf8') + decipher.final('utf8');
  } catch { return null; }
}

export function isEncrypted(value) {
  return typeof value === 'string' && value.split(':').length === 3;
}
