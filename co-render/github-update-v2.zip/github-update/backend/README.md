# ContaOffice Backend

API REST para ContaOffice — Sistema de gestión contable para Chile.

## Stack
- Node.js + Express
- MongoDB (Atlas)
- JWT Authentication
- Puppeteer (scraping SII)
- AES-256-GCM (encriptación de credenciales)

## Endpoints

### Auth
- `POST /api/auth/register` — Crear cuenta
- `POST /api/auth/login` — Login → retorna JWT
- `GET /api/auth/me` — Perfil del usuario autenticado

### Empresas
- `GET /api/companies` — Listar empresas
- `POST /api/companies` — Crear empresa
- `PATCH /api/companies/:id` — Actualizar empresa

### Tareas
- `GET /api/tasks` — Listar tareas
- `POST /api/tasks` — Crear tarea
- `PATCH /api/tasks/:id` — Actualizar/cambiar estado

### SII
- `POST /api/sii/consultar` — Scraping F29, F22, DJ desde sii.cl

## Variables de entorno

Ver `.env.example`

## Deploy en Railway

1. Conectar repo en Railway
2. Agregar variables de entorno
3. Build: `npm install`
4. Start: `npm start`

## Frontend

El frontend es un archivo HTML estático desplegado en Netlify:
`https://contaoffice-demo.netlify.app`
